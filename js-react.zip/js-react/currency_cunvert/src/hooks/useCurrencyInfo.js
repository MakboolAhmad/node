import { useEffect,useState } from 'react';

function useCurrencyInfo(currency) {
    const [currencyInfo, setCurrencyInfo] = useState({});
    useEffect(() => {
        fetch(`https://open.er-api.com/v6/latest/${currency}`)
        .then(response => response.json())
        .then(response => setCurrencyInfo(response.rates))
    }, [currency]);
    
    return currencyInfo;
}

export default useCurrencyInfo