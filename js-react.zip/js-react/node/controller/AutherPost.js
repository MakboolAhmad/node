const {  PostModel } = require('../model/registration');




async function AutherPost(req,resp){
    console.log('Aggregated Results:', results());
    const data = {
        title: req.body.title,
        content:req.body.content,
        author:req.user.data.id
    }
    if(!data)
        return resp.status(400).json({message:'all filed required'});
    try {
        const post = new PostModel(data);
        await post.save();
        return resp.status(200).json({message:true,data:post});
    } catch (error) {
        return resp.status(401).json({message:error.message,data:error});
    }
}

module.exports={
    AutherPost
}