
require('dotenv').config();
const {  UserModel } = require('../model/registration');
const { createHmac } = require('node:crypto');
const {generateAccessToken}= require('../service/jwt');
const axios = require('axios');
const {mailOptions} = require('../service/mailTest')
const path = require('path');


async function UserReg(req, res) {
    const hash =createHmac('sha256', process.env.SECRET_KEY).update(req.body.password).digest('hex');
    const schema ={
        name: req.body.name,
        email: req.body.email,
        password: hash,
        age: req.body.age,
        address: req.body.address
        
    }
    try {
        const user = new UserModel(schema);
        await user.save();
        const jwt_token=generateAccessToken(user);
        res.status(201).json({
            message: 'registration successful',
            token: jwt_token
        });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
}
async function UserUpdateRecord(req,res){
    try {
        const user = await UserModel.findByIdAndUpdate(req.params.id, req.body, {new: true});
        if(!user) return res.status(404).json({ message: 'User not found' });
        res.json(user);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }    
}
async function DeleteBYUser(req, res) {
    try {
        const user = await UserModel.findByIdAndDelete(req.params.id);
        if(!user) return res.status(404).json({ message: 'User not found' });
        res.json(user);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
}

async function GetAllUser(req,res){
    axios.get('https://jsonplaceholder.typicode.com/posts/1').then((resp)=>{
        console.log(resp.data)
    })
    .catch(err=>{
        console.log(err);
    });
  
    try {
        const users = await UserModel.find();
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
    
}

async function MailSendTest(req,resp){
    const {from,to,subject,text}  = req.body;
    if(!from||!to||!subject||!text)
        return resp.json({message:'all field required'});
    const test = mailOptions(from,to,subject,text);
    if(!test)
        return resp.json({message:'no response by mail'});
    return resp.json({message:test,success:true});
}
function ChatApp(req,resp){
    // req.io.emit("new-message", { content: req.body.content });
    console.log(req.io);
    return resp.json({ success: req.io });

}
module.exports = {
    UserReg,
    UserUpdateRecord,
    DeleteBYUser,
    GetAllUser,
    MailSendTest,
    ChatApp
};
