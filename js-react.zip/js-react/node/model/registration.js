const mongoose = require('mongoose');
const { type } = require('os');

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    age: {
        type: Number,
        required: true
    },
    address: {
        type: String,
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    },
    updated_at: {
        type: Date,
        default: Date.now
    }
});
const userPost=new mongoose.Schema({
    title: {
        type: String,
        required: true, 
        trim: true,     
      },
      content: {
        type: String,
        required: true, 
      },
      author: {
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'User',
        required: true, 
      },
      createdAt: {
        type: Date,
        default: Date.now, 
      },
      updatedAt: {
        type: Date,
        default: Date.now,
      },
      tags: [{
        type: String, 
      }],
      isPublished: {
        type: Boolean,
        default: false, 
    }

});

const UserModel = mongoose.model('User', userSchema);
const PostModel = mongoose.model('Post', userPost);
module.exports = {UserModel,PostModel};
