const express = require("express")
const router = express.Router()
const {UserReg,UserUpdateRecord,DeleteBYUser,GetAllUser,MailSendTest,ChatApp}  =  require('../controller/User');
const {Authentication} = require('../middleware/Auth');
const {AutherPost}=require('../controller/AutherPost');

router.post("/register", UserReg);
router.post("/mailTest", MailSendTest);
router.put("/update/:id", UserUpdateRecord);
router.delete("/delete/:id", DeleteBYUser);
router.post('/chat',ChatApp);
router.post('/userPost',Authentication,AutherPost);
router.get("/",Authentication, GetAllUser);
module.exports = router;