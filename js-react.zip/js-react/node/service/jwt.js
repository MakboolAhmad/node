const jwt = require('jsonwebtoken');

const secret_key="mak@1hr"

function generateAccessToken(user) {
    const payload = {
      id: user._id,
      email: user.email,
      password: user.password
    };
    return jwt.sign(payload, secret_key, { expiresIn: '8h' });
}
function verifyAccessToken(token) {
  
    try {
      const decoded = jwt.verify(token,  secret_key);
      return { success: true, data: decoded };
    } catch (error) {
      return { success: false, error: error.message };
    }
}

module.exports ={
    generateAccessToken,
    verifyAccessToken
}