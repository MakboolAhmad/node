const mongoose = require('mongoose');

function dbConnection(option){
    return mongoose.connect(option);
}
module.exports = {
    dbConnection
}