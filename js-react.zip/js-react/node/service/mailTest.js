const nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport({
    host: "sandbox.smtp.mailtrap.io",
    port: 465,
    secure: false,
    auth: {
      user: "c2d86690b5a4b6",
      pass: "********464d"
    }
  });

function mailOptions(from,to,subject,text){
    return ({
        from:from,
        to:to,
        subject:subject,
        text:text
    })
}

transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error+' send mail Error');
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
transporter.verify(function(error, success) {
    if (error) {
          console.log(error+' verify test');
    } else {
          console.log('Server is ready to take our messages');
    }
  });  
module.exports={
    mailOptions
}  