const fs = require('fs');
const path = require('path');
const logToFile=(message)=>{
    const file_Path_name = path.join(__dirname,'app.log');
    const logMessage = `${new Date().toISOString()} - ${message}\n`;
    fs.appendFile(file_Path_name,logMessage,(err)=>{
      if(err) return console.log('Failed to write to log file', err);
    });
};

module.exports={
    logToFile
}