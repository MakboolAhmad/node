const router = require('./route/Router');
const {Buffer} = require('node:buffer');

const port = 3000;
var bodyParser = require('body-parser')
var express = require('express')
const path = require('path');
var app = express()
const {dbConnection } = require('./service/dbConnection');
app.use(bodyParser.json())
dbConnection('mongodb://localhost:27017/Nimbus').then(()=>console.log('connection by db'))


app.use(express.static(path.join(__dirname, 'views')));


const http = require('http');

const server = http.createServer(app);
const { Server } = require("socket.io");

const io = new Server(server,{ cors: { origin: "*" } })
     
app.use((req,resp,next)=>{
    io.req=io;
    return next();
})

app.get('/chatApp',(req,resp)=>{
    resp.sendFile(path.join(__dirname, 'views', 'chat.html'));
})
io.on('connection', (socket) => {
    console.log('a user connected');
    socket.on('chat message', (msg) => {
        io.emit('chat message', msg);
    });
});
app.use('/', router);

server.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})
