const {generateAccessToken,verifyAccessToken}= require('../service/jwt');
const {logToFile} = require('../service/logFile');
function Authentication(req,res,next) {
        const authHeader = req.headers['authorization'];
        const serverName = req.hostname;
        const serverPath = req.originalUrl;
        const pathName = req.method;
        if(!authHeader) return res.status(401).json({message: 'Token is required'});

        const result = verifyAccessToken(authHeader);
        
        const accessToken = result.success
        if(!accessToken) return res.status(403).json({message: 'Token is invalid'});
        logToFile(`Server name: ${serverName}, Server path: ${serverPath} ,Methods Name :${pathName} `);
        
        req.user = result
        next();

}
module.exports = {
        Authentication
};