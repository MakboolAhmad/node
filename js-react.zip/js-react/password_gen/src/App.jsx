import { useState , useCallback ,useEffect , useRef} from 'react'


function App() {
  const [password, setPassword] = useState('')
  const [length, setLength] = useState('8')
  const [allowedChar, setAllowedChar] = useState('false')
  const [allowedNumbers , setAllowedNumbers] = useState('false')

 

  const passwordGenerator = useCallback(()=>{
    let pass = ''
    let str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    if(allowedChar) str += '!@#$%^&*()_+|}{?><,./;'
    if(allowedNumbers)  str += '0123456789'
    for (let i = 1; i < length; i++) {
    let char = Math.floor(Math.random() * str.length + 1)
    pass += str.charAt(char)
      
    }

    setPassword(pass)
  },[length,allowedChar,allowedNumbers])



  useEffect(()=>{
    passwordGenerator()
  },[length,allowedChar,allowedNumbers,passwordGenerator])
let copyPasswordToClipboard = useCallback(( ()=>{
  passwordRef.current?.select()
  passwordRef.current?.setSelectionRange(0,100)
  window.navigator.clipboard.writeText(password)
  
}),[password])

const passwordRef = useRef(null)

return(
<div className='w-full max-w-md m-auto shadow-md rounded-lg px-4 py-3 my-8 text-orange-800 bg-gray-700 '>
<h1 className='text-3xl text-center text-white font-bold my-2'>Password Generator</h1>
  <div className='flex shadow rounded-lg overflow-hidden mb-4'>
  <input 
    type="text"
    value={password}
    className='w-full px-3 py-2 outline-none rounded-l-lg '
    placeholder='Password'
    ref={passwordRef}
    
    readOnly
    />
    <button  
     onClick={copyPasswordToClipboard}
     className='text-blue px-3 py-1 bg-blue-900 text-white
    
    '>Copy</button>

    </div>
    <div className='flex text-sm gap-x-2'> 

     
    </div>
  
  <div className=' flex justify-center text-sm gap-x-2 items-center'> 
  <input
    type="range" 
    value={length}
    min="4"
    max="100"
    onChange={(e)=>{setLength(e.target.value)}}
     />
     <label htmlFor="length" className='text-orange-500'> Length:({length})</label>
    
     <input
    type="checkbox" 
    defaultChecked={allowedNumbers}
    onChange={()=>{
      setAllowedNumbers((prev)=>!prev)
    }}
    id='numberInput'
     />
     <label htmlFor="numberInput" className='text-orange-500'>Numbers</label>


     
     <input
    type="checkbox" 
    defaultChecked={allowedChar}
    id='charInput'
    onChange={()=>{
      setAllowedChar((prev)=>!prev)
    }}
    
     />
     <label htmlFor="charInput" className='text-orange-500'>Characters</label>
     </div>



     






     
</div>
)
}

export default App
