import Login from "./componets/Login"
import Profile from "./componets/Profile"
import UserContextProvider from "./context/UserContextProvider"
import Registration from "./componets/Registration"

function App() {
 
  return (
    <>
      <UserContextProvider>
      <h2>welcome use context api</h2> 
      <Registration/>
      <Profile/>
      </UserContextProvider> 
    </>
  )
}

export default App
