import React from 'react'
import UserContext from '../context/UserContext'

function Profile() {
    const {user} = React.useContext(UserContext)
    console.log(user);
     if(!user) return <h2> Not login</h2>
     return  <h1>{user.password} login profile</h1> 
}

export default Profile