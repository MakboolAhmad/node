import React from "react";
import UserContext from "../context/UserContext";

function Registration(){
    const[name,setName]= React.useState('');
    const[email, setEmail]= React.useState('');
    const[password, setPassword]= React.useState('');
    const{setUser} = React.useContext(UserContext)
     const handler =(e)=>{
        e.preventDefault();
        setUser({name, email, password});
    }
    return <>
      <h1>Registration Form</h1>
      <input type="text" value={name} onChange={(e)=>setName(e.target.value)} name="registration" placeholder="Registration"/>
      <input type="email" value={email}  onChange={(e)=>setEmail(e.target.value)} name="email" placeholder="Email"/>
      <input type="password" name="password"  onChange={(e)=>setPassword(e.target.value)} value={password}  placeholder="Password"/>
      <button onClick={handler}> Submit</button>
    </>
}
export default Registration;