import React from 'react'
import UserContext from '../context/UserContext';


function Login() {
    const[username,setUserName] =React.useState('');
    const[password,setPassword] = React.useState('');
    const {setUser } = React.useContext(UserContext);
    const handler = (e)=>{
        e.preventDefault();
        setUser({username,password})
    }
  return (
    <div>
        <h2>SignIN</h2>
        <div>
        <input type="text" value={username} onChange={(e)=>setUserName(e.target.value)} placeholder="Username" />
        <br />
        </div>
       <div>
       <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} 
        placeholder="Password" />
        <br />
       </div>
       
        <button onClick={handler}>Submit</button>
    </div>
  )
}

export default Login